import UIKit

var str = "Hardest Part"


/*1. Остров Манхэттен был приобретен поселенцами за $24 в 1826 г. Каково было бы в настоящее время состояние их счета, если бы эти 24 доллара были помещены тогда в банк под 6% годового дохода?
 */

// we have a ilandsPrice
var price = 24.0

// we have a years
let yearOfBuying = 1826
let currentYear = 2019
var result = 0.0
// we can use for in to find the result
for _ in 1826..<2019{
    
 // price = price * 1.06
    
  price += price * 0.06
    
}

print(price)


/*
 2. Ежемесячная стипендия студента составляет 700 гривен, а расходы на проживание превышают ее и составляют 1000 грн. в месяц. Рост цен ежемесячно увеличивает расходы на 3%. Определить, какую нужно иметь сумму денег, чтобы прожить учебный год (10 месяцев), используя только эти деньги и стипендию.
 */
//we have a costs
var costs = 1000.0
var array: [Double] = [] //array of our costs with percent

for _ in 1...10{
    let percentPerYear = costs * 0.03 // percent per year
    
    costs += percentPerYear
    array.append(costs)
    //print(array)
    //print(costs)
}
//
var resultForStudent = 0.0
for i in array{
    resultForStudent += i
}
print(resultForStudent)









