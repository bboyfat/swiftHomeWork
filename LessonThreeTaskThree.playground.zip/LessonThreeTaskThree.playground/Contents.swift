import UIKit
import Foundation
var str = "Hard Task Three"



var x = 51515

// i want to conver my int value to String
var intToString = String(x)
// than i can reverse this value in this simple way
var reverse = String(str.reversed())
// and now we can see, is this value a palendrom or no
if reverse == intToString {
    print("this value is palendrom!")
} else {
    print("this value is not a palendrom!")
}
