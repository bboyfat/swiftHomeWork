import UIKit
import Foundation

let x = 7.3, y = 13.4, z = 10.1 // зада>м координаты xyz



let b = (x * x) + (y * y) + (z * z)//находим сумму квадратов координат

let a = sqrt(b) // извлекаем квадратный корень и получаем длину вектора
print("длинна вектора составляет \(a)")



/* ---------- Часть 2---------------------- */



var num = 7890


var str = String(num)

var reverse = String(str.reversed())

print(reverse)



for i in str.reversed(){
    print(i, terminator: "")
}
