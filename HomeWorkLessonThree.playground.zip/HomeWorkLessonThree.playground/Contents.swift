import UIKit
import Foundation

var str = "Home Work Lesson Three"
//============ Optional ========= if else condition ========= Logigal Operator != =============
var optionalInt: Int? = nil

var nonOptionalValue  = 100

if nonOptionalValue != optionalInt {
    print("your value is non optrional and = \(nonOptionalValue)")
} else {
    print("Looks like you have a nil, my friend")
}
// ============================== ternary Operator ===============
var tern = nonOptionalValue != optionalInt ? nonOptionalValue + 100: nil

//============= Tuples ================
let myTuple: (Bool, Int, Bool, Float, String) = (true, 12, false, 12.5, "Some String")
let anotherTuple = ("Jack", 34, false)

var name = anotherTuple.0
var age = anotherTuple.1
var isMarried = anotherTuple.2

var (firstName, hisAge, isHeMarried) = anotherTuple

var againName = firstName
var againAge = hisAge
var doesHeMerried = isHeMarried

var (_, onlyAge, _) = anotherTuple
print(onlyAge)


//============== if else condition with D =================

var tupleForD = (15, 2, 23)

var a = tupleForD.0
var b = tupleForD.1
var c = tupleForD.2

func calculate(a: Int, b: Int, c: Int) -> (x1: Int, x2: Int) {
    var x1: Int
    var x2: Int
    var d = 0
    d = b * b - 4 * a * c
    if d > 0{
        var f = Int(sqrt(Double(d)))
        x1 = (-b - f) / (2 * a)
        x2 = (-b + f) / (2 * a)
        print("D > 0, so x1 = \(x1), and x2 = \(x2)")
    } else if d == 0 {
        x1 = -(b / (2 * a))
        x2 = x1
        print("D = 0, and x = \(x1)")
    } else {
        x1 = 0
        x2 = x1
        print(" D <0")
    }
    
    return (x1,x2)
}
