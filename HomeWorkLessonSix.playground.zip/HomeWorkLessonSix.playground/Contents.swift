import UIKit

var str = "Home Work Lesson Six"

// ============================= Part ONE =================================
/*
 1. Написать функцию которая принимает вариативный параметр типа Int и возвращает значения количества четных и нечетных элементов параметра
 */
func evenAndOddNumbers(_ sender: Int) ->(even: Int, odd: Int){
    var x = sender
    var y = 0
    // we need to split our number for odd and even digits. I decided to use array for this
    var evenArray: [Int] = []
    var oddArray: [Int] = []
    // we can't use for because we don't know how many wi will have in our int variable, but we can use while
    while x > 0{
        x /= 10
        y = x % 10
        // with if else we can append our digits to our arrays
        if y % 2 == 0 && y > 0{
           evenArray.append(y)
        } else if y % 2 >= 0{
            oddArray.append(y)
            }
    }

    
    return (evenArray.count,oddArray.count)
}
// my int number
var number = 1241352523

print("count of even numbers = \(evenAndOddNumbers(number).even) \ncount of odd numbers = \(evenAndOddNumbers(number).odd)")

// ============================= Task Two =================================

/*
 2. Написать функцию которая принимает две переменные и меняет их значения местами без использования третей переменной.
 */



func rotatevariables (var1: inout Int, var2: inout Int) ->(Int, Int){
    var1 = var1 + var2
    var2 = var1 - var2
    var1 = var1 - var2
   
    return (var1, var2)
}

var one = 321
var two = 123

print(rotatevariables(var1: &one, var2: &two))


// ============================= Task Three =================================

/*
 3. Создайте функцию которая бы принимала массив и возвращала массив в обратном порядке.
 
 */
var myArr = [1,2,3,4,5]
func reverseArray(_ array: [Int]) -> [Int]{
    
    let d: [Int] = array.reversed()
    
    return d
}

print("\(myArr) reversed = \(reverseArray(myArr))")


// Second way to reverse myArray

func anotherWayToReverseArray(_ array: [Int]) -> [Int]{
    var x = array
    var d: [Int] = []
    var y = 0
    if x.count > 0{
    while x.count > 0{
        y = x.last!
        d.append(y)
        x.removeLast()
    
    }
    }
    return d
}

print("Second Way to reverse \(myArr) = \(anotherWayToReverseArray(myArr))")

// ============================= Task Four =================================

/*
 4. Создайте функцию, которая принимает строку, убирает из нее все знаки препинания, делает все гласные большими буквами, согласные - маленькими.
 */


func changeMyString(_ someString: String) -> String {
    
    var newString = someString.uppercased()
    var returnString = ""
    // deleting "",;.!$#
    for index in stride(from: someString.count - 1, through: 0, by: -1){
        
        if !(((newString[newString.index(newString.startIndex, offsetBy: index)] >= "A") && (newString[newString.index(newString.startIndex, offsetBy: index)] <= "Z")) || newString[newString.index(newString.startIndex, offsetBy: index)] == " "){
                  newString.remove(at: newString.index(newString.startIndex, offsetBy: index))
        }
    
    }
    // appending chars to new string
    for char in newString{
       
        if char == "A" || char == "E" || char == "Y" || char == "U" || char == "I" || char == "O" || char == "Q" {
              returnString.append(String(char).lowercased())
            
        } else {
            returnString.append(char)
        }
    }
    
    
    return returnString
    
    
}

var myString = "Referring to himself as a \"consulting detective\" in the stories, Holmes is known for his proficiency with observation, forensic science, and logical reasoning that borders on the fantastic, which he employs when investigating cases for a wide variety of clients, including Scotland Yard."

print(changeMyString(myString))


