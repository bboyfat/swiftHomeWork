import UIKit

var str = "Home Waork Lesson 6 Part Two"


/*
 Доп дз по 6 теме:
 1. Создать функцию, которая будет принимать строчный параметр, и возвращать массив строк, состоящий из отдельных слов вашего принимаемого параметра.
 2. У вас есть словарь, который содержит в себе ключ (имя человека) и значение (возраст). Используя цикл и функцию, выведите в консоль отдельно строку, подобную этой - "It's Mike and he is 15".
 3***. Написать функцию, которая будет принимать массив, содержащий в себе строки и числа. Функция должна вернуть два параметра: 1-й - сумму всех чисел, 2-й - строку, содержащую в себе все слова из массива через пробел. Используя результат функции, посчитать в получившейся строке отдельно количетсво гласных, согласных, пробелов и всех знаков препинания.
 */

// ============================ Task One ==============================


/*
  1. Создать функцию, которая будет принимать строчный параметр, и возвращать массив строк, состоящий из отдельных слов вашего принимаемого параметра.
 */

func stringToArray(_ string: String) -> [String]{
    let myString = string
    let array = myString.components(separatedBy: " ")
    
    return array
}

let myString = " 1. Создать функцию которая будет принимать строчный параметр и возвращать массив строк состоящий из отдельных слов вашего принимаемого параметра"

print(stringToArray(myString))




//============================= Task Two ====================================


func nameAndAge(_ dict: [String: Int]){
    
   
    for (key, value) in dict{
       print("It's \(key ) and he is \(value)")
      
    }
    
}

var nameAndAges = ["John": 23, "Mike": 13, "Greg": 42]

print(nameAndAge(nameAndAges))


//============================= Task Three ====================================


/*
 3***. Написать функцию, которая будет принимать массив, содержащий в себе строки и числа. Функция должна вернуть два параметра: 1-й - сумму всех чисел, 2-й - строку, содержащую в себе все слова из массива через пробел. Используя результат функции, посчитать в получившейся строке отдельно количетсво гласных, согласных, пробелов и всех знаков препинания.
 
 */


func stringAndint(_ array: [Any]) -> (String, Int) {
    
    var sum = 0
    var myString = ""
    var countOfSpaces = ""
    var volwes = ""
    var punctuationMarks = ""
    
    for i in 0..<array.count{
        if ((array[i] as? Int) != nil){
            sum += array[i] as! Int
        } else if ((array[i] as? String) != nil){
            myString += array[i] as! String + " "
        }
    }
    for char in myString{
        if char == " "{
            countOfSpaces.append(char)
        } else if (String(char).lowercased() == "a" || String(char).lowercased() == "q" || String(char).lowercased() == "e" || String(char).lowercased() == "u" || String(char).lowercased() == "y" || String(char).lowercased() == "o" || String(char).lowercased() == "i"){
            volwes.append(char)
        } else if (String(char).lowercased() == "," || String(char).lowercased() == "." || String(char).lowercased() == "!" || String(char).lowercased() == "?" || String(char).lowercased() == "/" || String(char).lowercased() == "\"" || String(char).lowercased() == "/") {
            punctuationMarks.append(char)
        }
    }
    print("sum is equal = \(sum), and string = \(myString), count of spaces = \(countOfSpaces.count) \n countOfVolwes = \(volwes.count), and consonantsCount = \(myString.count - volwes.count - countOfSpaces.count - punctuationMarks.count) \n count of punctuationMarks = \(punctuationMarks.count)")
    return (myString, sum)
}

var arrayIntAndString: [Any] = ["Mark", 42, "Wop", 1, "Jake", 123, "AUDI, BMW, VAZ. LAZ!", 1515.21123, true, "someWord", 23, "Hello", 555]

stringAndint(arrayIntAndString)
