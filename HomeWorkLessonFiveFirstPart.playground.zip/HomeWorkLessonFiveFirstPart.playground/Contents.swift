import UIKit

var str = "Home Work Lesson 5"



//========================== PART ONE ==============================
     /*Дано число. Найти сумму и произведение его цифр.*/

let number = 345
var myArray: [Int] = []
// first we need to split our number for digits
var num3 = number % 10

var num2 = (number / 10) % 10

var num1 = (number / 100) % 10
// then we need to aapend this digits to an array
myArray.append(num1)
myArray.append(num2)
myArray.append(num3)
myArray
// and finally we can find thw sum and mult of our digits with for-in
var sum = 0
var mult = 1
if myArray.count > 0{
    
    
for i in myArray {
    
    sum += i
    mult *= i
    
}
}

print(myArray)

print("Sum = \(sum), and multiply = \(mult)")

//========================== PART TWO ==============================
/*
 Дано число, дана степень. Возвести число в степень используя for-in
 */
// we have a number and degree
var newNumber = 3
var degree = 5
// we need to create a new variable to get the result
var result = 1
// to raise three to the fefth degree we can use for-in
for _ in 1...degree{
    result *= newNumber
}

print("\(newNumber) in the fifth degree equals \(result)")

//========================== PART THREE ==============================
// creatin a new array with 10 float numbers
var newArray: [Float] = [1.5, 2.3, 1.7, 12.1, 3.1, 4.9, 2.8, 3.1, 8.2, 113.7]

newArray.count


// new variable to get sum
var sum1: Float = 0.0
// with for in, i can find sum
for i in newArray{
    
    sum1 += i
}
//and then i can find mean
var arithmeticMean: Float = sum1 / 10

print("sum of my array is equals \(sum1) \nAnd Arithmetic Mean equals \(arithmeticMean)")
