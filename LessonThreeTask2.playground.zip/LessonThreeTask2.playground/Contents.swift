import UIKit

var str = "Hard Task Two"


var number = 332
// we need to split our number for digits
var num3 = number % 10
var op1 = (number - num3) / 10
var num2 = op1 % 10
var num1 = (op1 - num2) / 10

// and now we can find the same digits

if (num1 == num2) || (num2 == num1){
    print("num1 = num2 = \(num1)")
} else if num2 == num3 {
    print("num2 = num3 = \(num2)")
} else if num3 == num1 {
    print("num3 = num1 = \(num1)")
} else {
    print("you don't have any same digits in your number!")
}
