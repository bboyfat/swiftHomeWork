import UIKit

var str = "Hello, playground"

/*
 1. Вывести на экран все числа до заданного и в обратном порядке до 0
 2. Подсчитать общее количество делителей числа и вывести их
 3. Проверить, является ли заданное число совершенным и найти их
 */

//============== task One ===============
var first = 0
var last = 5


    
    repeat{
        last -= 1
        first += 1
        
        print("\(first)    \(last)")
    } while last > 0


    

print("==========================================")

// /============== task two, three ===============

var number = 6

var aArray: [Int] = []
var x = 0

for i  in 1...number{
    x = number % i
    if x == 0{
        aArray.append(i)
    } else {
        continue
    }
}
print(aArray.count)
var isTrue = false
var y = 0
for i in aArray{
    y += i
    if y == number{
        isTrue = true
    }
}
if isTrue{
    print("\(number) is a perfect number ")
} else {
    print ("your number is not perfect")
}

//
