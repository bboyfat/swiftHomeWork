import UIKit

var str = "Hard Task One"


var x = 7596
// first af all we need to split our number for digits
var num1 = x % 10
var op1 = x / 10
var num2 = op1 % 10
var op2 = (op1 - num2) / 10
var num3 = op2 % 10
var num4 = (op2 - num3) / 10

// then we can find the max value

if (num1 > num2) && (num1 > num3) && (num1 > num4) {
    print( "the biggest number is \(num1)")
} else if (num2 > num1) && (num2 > num3) && (num2 > num4) {
    print("the biggest number is \(num2)")
} else if (num3 > num1) && (num3 > num2) && (num3 > num4) {
    print("the biggest number is \(num3)")
} else if (num4 > num1) && (num4 > num2) && (num4 > num1) {
    print("the biggest number is \(num4)")
} else {
    print("enter please 4 digits")
}
// and minimum value
if (num1 < num2) && (num1 < num3) && (num1 < num4) {
    print( "the min number is \(num1)")
} else if (num2 < num1) && (num2 < num3) && (num2 < num4) {
    print("the min number is \(num2)")
} else if (num3 < num1) && (num3 < num2) && (num3 < num4) {
    print("the min number is \(num3)")
} else if (num4 < num1) && (num4 < num2) && (num4 < num1) {
    print("the min number is \(num4)")
} else {
    print("enter please 4 digits")
}
