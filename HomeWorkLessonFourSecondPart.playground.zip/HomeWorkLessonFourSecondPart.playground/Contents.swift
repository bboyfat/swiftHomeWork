import UIKit

var str = "Hard Tasks"

//================================== PART ONE ==================================

// creating a new string with 10 chars
let str1 = "Helloworld"

// creating a new str with chars from st1

let str2 = "\(str1[str1.startIndex])" + "\(str1[str1.index(str1.startIndex, offsetBy: 2)])" + "\(str1[str1.index(str1.startIndex, offsetBy: 4)])" + "\(str1[str1.index(str1.startIndex, offsetBy: 6)])" + "\(str1[str1.index(str1.startIndex, offsetBy: 8)])"
str2

print ("odd characters in \(str1) is \(str2)")

// creating str with even characters

let str3 = "\(str1[str1.index(after: str1.startIndex)])" + "\(str1[str1.index(str1.startIndex, offsetBy: 3)])" + "\(str1[str1.index(str1.startIndex, offsetBy: 5)])" + "\(str1[str1.index(str1.startIndex, offsetBy: 7)])" + "\(str1[str1.index(str1.startIndex, offsetBy: 9)])"

print("even characters in \(str1) is \(str3)")


//================================== PART TWO ==================================

// new string
let myString = "Hey theree"

myString.count

// than we need to split this string to a characters

let reversedMystring = "\(myString[myString.index(before: myString.endIndex)])" + "\(myString[myString.index(myString.startIndex, offsetBy: 8)])" + "\(myString[myString.index(myString.startIndex, offsetBy: 7)])" + "\(myString[myString.index(myString.startIndex, offsetBy: 6)])" + "\(myString[myString.index(myString.startIndex, offsetBy: 5)])" + "\(myString[myString.index(myString.startIndex, offsetBy: 4)])" + "\(myString[myString.index(myString.startIndex, offsetBy: 3)])" + "\(myString[myString.index(myString.startIndex, offsetBy: 2)])" + "\(myString[myString.index(myString.startIndex, offsetBy: 1)])" + "\(myString[myString.index(myString.startIndex, offsetBy: 0)])"

// and finally we need to print reversed string

print ("reversed \(myString) = \(reversedMystring)")


//================================== PART THREE ==================================

// creating new string with 10 chars


var finalString = "Have had !"

finalString.count

/*   -------------------- first way -------------- if we know where is "a" in our string

// first way to remove a it's:

finalString.remove(at: finalString.index(finalString.startIndex, offsetBy: 1))
finalString.remove(at: finalString.index(finalString.startIndex, offsetBy: 5))

print(finalString)
*/
//---------------------- second way ---------------


if finalString[finalString.index(finalString.startIndex, offsetBy: 9)] == "a" {
    finalString.remove(at: finalString.index(finalString.startIndex, offsetBy: 9))
    
}
if finalString[finalString.index(finalString.startIndex, offsetBy: 8)] == "a" {
    finalString.remove(at: finalString.index(finalString.startIndex, offsetBy: 8))
}
if finalString[finalString.index(finalString.startIndex, offsetBy: 7)] == "a" {
    finalString.remove(at: finalString.index(finalString.startIndex, offsetBy: 7))
}
if finalString[finalString.index(finalString.startIndex, offsetBy: 6)] == "a" {
    finalString.remove(at: finalString.index(finalString.startIndex, offsetBy: 6))
}
if finalString[finalString.index(finalString.startIndex, offsetBy: 5)] == "a" {
    finalString.remove(at: finalString.index(finalString.startIndex, offsetBy: 5))
}
if finalString[finalString.index(finalString.startIndex, offsetBy: 4)] == "a" {
    finalString.remove(at: finalString.index(finalString.startIndex, offsetBy: 4))
}
if finalString[finalString.index(finalString.startIndex, offsetBy: 3)] == "a" {
    finalString.remove(at: finalString.index(finalString.startIndex, offsetBy: 3))
}

if finalString[finalString.index(finalString.startIndex, offsetBy: 2)] == "a" {
    finalString.remove(at: finalString.index(finalString.startIndex, offsetBy: 2))
}

if finalString[finalString.index(finalString.startIndex, offsetBy: 1)] == "a" {
    finalString.remove(at: finalString.index(finalString.startIndex, offsetBy: 1))
}
if finalString[finalString.startIndex] == "a" {
    finalString.removeFirst()
}

print("finalString without \"a\" = \(finalString)")




