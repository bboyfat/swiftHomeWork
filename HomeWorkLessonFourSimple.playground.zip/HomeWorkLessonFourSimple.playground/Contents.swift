import UIKit

var str = "Hemo Work Lesson Four"


//============================ PART ONE ==============================


// create an empty string

var emptyString = ""
print(emptyString)

emptyString = "Value of the \nfirst string"
print(emptyString)
// create second string
var anotherEmptyString = "Value of the second string"
// checking the string's values
if emptyString != anotherEmptyString{
    emptyString = anotherEmptyString
    print(emptyString)
}


//============================ PART TWO ==============================


let constStringOne = "first string"
let constStringTwo = "second string"

// we need to print first and last value of longer string
if constStringOne.count > constStringTwo.count{
   print(constStringOne[constStringOne.startIndex], constStringOne[constStringOne.index(before: constStringOne.endIndex)])
} else {
    print(constStringTwo[constStringTwo.startIndex], constStringTwo[constStringTwo.index(before: constStringTwo.endIndex)])
}

//============================ PART THREE ==============================


let thirdTaskString = "Helloo"
// first we need to split our string to a characters
let ch0 = thirdTaskString[thirdTaskString.startIndex]
let ch1 = thirdTaskString[thirdTaskString.index(after: thirdTaskString.startIndex)]
let ch2 = thirdTaskString[thirdTaskString.index(thirdTaskString.startIndex, offsetBy: 2)]
let ch3 = thirdTaskString[thirdTaskString.index(thirdTaskString.startIndex, offsetBy: 3)]
let ch4 = thirdTaskString[thirdTaskString.index(thirdTaskString.startIndex, offsetBy: 4)]
let ch5 = thirdTaskString[thirdTaskString.index(before: thirdTaskString.endIndex)]

// and finally we need to print a new string

print("reversed string = \(ch5)\(ch4)\(ch3)\(ch2)\(ch1)\(ch0)")

